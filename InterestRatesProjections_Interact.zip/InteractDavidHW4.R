library(ggplot2)
# install.packages("gpclib", type="source") # RUN THIS IF YOU GET AN ERROR ON 'fortify' BELOW
library(rgeos)
library(maptools)
library(data.table)
library(RColorBrewer)
library(corrplot)
library(VIM)
library(plotly)
library(lubridate)


#setwd("C:/Users/David W Liao/Dropbox/DePaulUniv/CSC465/HW1") 
setwd("C:/Users/David/Google Drive/CSC465Proj/HW4plots/David")

#--- USDebt as % of GDP ----------------------
filePath <- "StLouisFed_GovDebt_QterlyasPCTGDP_1970to2016.csv"

GDPasPct <- read.csv(filePath, head=TRUE, sep=",", stringsAsFactors = F)  
View(GDPasPct)

GDPasPct$Date = as.Date(GDPasPct$Quarterly_Date, format='%Y-%m-%d')
#GDPasPct$Date = as.Date(GDPasPct$Quarterly_Date)

GDP.missv = aggr(GDPasPct, prop=FALSE, numbers=TRUE)
summary(GDP.missv)


# setup the base data for Debt as PCT GDP
GDP1 = ggplot(GDPasPct, aes(x=Date, y=GDPasPct$USDebt_asPctGDP) )
#add a layer for plotting of points
GDP1  = GDP1 + geom_point(size=0.5) +
        geom_line(aes(group=1), size=0.5, colour="#000099") +
        scale_y_discrete(limits=c(30, 40, 50, 60, 70, 80, 90, 100, 110,120))
        #scale_y_discrete(limits=c('30', '40', '50', '60', '70', '80', '90', '100', '110'))
        #expand_limits(y=100)

GDP1 + ggtitle("US Debt as % of GDP 1966-2015")  + ylab('US Debt as % of GDP') 

ggplotly()


#--- USDebt as $Trillions ----------------------
file2 <- "StLouisFed_GovDebt_Qterly_1970to2016.csv"
USdebt <- read.csv(file2, head=TRUE, sep=",", stringsAsFactors = F)  
View(USdebt)

USdebt$Date = as.Date(USdebt$Quarterly_Date, format='%m/%d/%Y')

Debt1 = ggplot(USdebt, aes(x=Date, y=USdebt$USGovDebtMillions) )
#add a layer for plotting of points
Debt1  = Debt1 + geom_point(size=0.5) +
          geom_line(aes(group=1), size=0.5, colour="#a50f15") +
          scale_y_log10()
#####-->  plotly cannot handle Log Scale
          #+
          #coord_trans(y="log10")
Debt1
Debt1 + ggtitle("US Debt in $Millions 1966-2015")  + ylab('US Debt $Millions in Log10') 

ggplotly()

##use pre-converted Log 10 values
Debt2 = ggplot(USdebt, aes(x=Date, y=USdebt$USGovDebt_Log10Millions) )
#add a layer for plotting of points
Debt2  = Debt2 + geom_point(size=0.5) + geom_line(aes(group=1), size=0.5, colour="#a50f15") + 
          ggtitle("US Debt in $Millions 1966-2015")  + ylab('US Debt $Millions in Log10') 
Debt2 + ggtitle("US Debt in $Millions 1966-2015")  + ylab('US Debt $Millions in Log10')
ggplotly()

#Debt2 + coord_trans(y="log10")    ##Do NOT use coord_trans log scale with plotly


#--- USDebt as $Trillions ----------------------
file5 <- "StLouisFed_TreasuryRates1953to2016.csv"
TRates <- read.csv(file5, head=TRUE, sep=",", stringsAsFactors = F)  

#merge 1yr and 10 yr TRates into 1 columns
HistRates = melt(TRates, id=c("Monthly_Date"))
View(HistRates)
names(HistRates)[2] = "TreasuryRates"

HistRates$Date = as.Date(HistRates$Monthly_Date, format='%Y-%m-%d')
View(HistRates)

HRates1 = ggplot(HistRates, aes(Date,value)) + geom_line(aes(colour=TreasuryRates), size= 1.3) + 
          geom_point(size=0.25)
          #geom_point(size=0.5, aes(shape = factor(TreasuryRates)))
HRates1 + ylab('Historical Treasury Rates in %') + 
  ggtitle('Historical US Treasury Rates 1% and 10%') +
  scale_color_brewer(type="qual",palette="Accent")
    
ggplotly()  

#--- Interest Rate Projections ----------------------
file4 <- "InterestPayProjections1.csv"
InterestPay <- read.csv(file4, head=TRUE, sep=",", stringsAsFactors = F)  
View(InterestPay)

# Melt collapses columns into one field like the "pivot" feature in Tableau
# The id parameter here tells what fields to keep (i.e. not "melt")
IntrProj = melt(InterestPay, id=c("Year"))
View(IntrProj)
names(IntrProj)[2] = "InterestRate"

IntrPay = ggplot(IntrProj, aes(Year,value)) + geom_line(aes(colour=InterestRate)) + geom_point(size=0.5)
#ggplot(IntrProj, aes(Year,value)) + geom_line(aes(colour=InterestRate))

IntrPay + ylab('Interest Expense in $ Millions') + 
        ggtitle('Debt Interest Expense Projections@ Rates 2.2% to 5.0%') +
          scale_color_brewer(type="qual",palette="Accent")
          #scale_fill_brewer(type="qual",palette="Accent")

ggplotly()





#--- White House Budget Surplus or Deficit ----------------------
file3 <- "WhiteHouse_USDeficitTab1.1.csv"
WHBudget <- read.csv(file3, head=TRUE, sep=",", stringsAsFactors = F)  
View(WHBudget)


WHBudget$Date2 = as.Date(WHBudget$Date, format='%d/%m/%Y')
library(lubridate)
WHBudget$Year2 = lubridate::year(WHBudget$Date2)

Deficit1 = ggplot(WHBudget, aes(x=Year2, y=WHBudget$Receipts) )

Deficit1 + geom_bar(stat='identity')
